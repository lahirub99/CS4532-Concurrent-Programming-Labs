# CS4532 - Concurrent Programming
## Lab 02 - 190077A,190601D

### Instructions on running the program
01. Open the provided directory in vscode.
02. In the terminal enter `javac solution2.java`
03. Next run the compiled program by entering `java solution2`
