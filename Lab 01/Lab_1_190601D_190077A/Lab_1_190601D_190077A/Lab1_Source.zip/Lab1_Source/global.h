#ifndef GLOBAL_VARS

#define GLOBAL_VARS

#define MAX 65535

#endif