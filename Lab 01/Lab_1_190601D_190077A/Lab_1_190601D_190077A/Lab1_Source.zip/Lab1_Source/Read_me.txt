Use "make" command for build.
Use "./prog" command for run the program.
Output csv files will be saved in output directory.
csv files will contain the execution times in micro seconds.