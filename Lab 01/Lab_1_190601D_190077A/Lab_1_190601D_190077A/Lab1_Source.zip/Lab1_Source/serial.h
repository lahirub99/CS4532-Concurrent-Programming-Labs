#ifndef SERIAL_RUN_H
#define SERIAL_RUN_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>

#include "linked_list.h"
#include "global.h"

//#define MAX 65535

unsigned long test_serial_run(int case_num);

#endif