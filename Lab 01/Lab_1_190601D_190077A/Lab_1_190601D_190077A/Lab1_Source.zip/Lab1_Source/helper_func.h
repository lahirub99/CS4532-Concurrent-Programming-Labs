#ifndef HELPER_FUNC_H
#define HELPER_FUNC_H

void shuffle(int *array, int n);

#endif // HELPER_FUNC_H
